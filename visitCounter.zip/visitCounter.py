import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('PageVisits')

    page_id = event.get('page_id', 'default_page') 

    try:
        response = table.update_item(
            Key={'PageID': page_id},
            UpdateExpression="SET VisitCount = if_not_exists(VisitCount, :start) + :inc",
            ExpressionAttributeValues={
                ':start': 0,
                ':inc': 1
            },
            ReturnValues="UPDATED_NEW"
        )
        return {
            'statusCode': 200,
            'body': f"Visit count for {page_id}: {response['Attributes']['VisitCount']}"
        }
    except ClientError as e:
        print(e.response['Error']['Message'])
        return {
            'statusCode': 500,
            'body': "Error updating visit count"
        }
