import boto3
import json
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('PageVisits') 

def lambda_handler(event, context):
    try:
        page_id = 'default_page'
        
        response = table.get_item(Key={'PageID': page_id})
        
        visit_count = int(response['Item']['VisitCount']) if 'Item' in response else 0

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*', 
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({'PageID': page_id, 'VisitCount': visit_count})
        }
    except Exception as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
